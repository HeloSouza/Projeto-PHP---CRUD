<?php

namespace App\Http\Controllers\Admin;

use Illuminate\Http\Request;
use App\Http\Controllers\Controller;

class CursoController extends Controller
{
    Route::get('/admin/cursos',
['as'=>'admin.cursos','uses'=>'Admin\CursoController@index']);
Route::get('/admin/cursos/adicionar',
['as'=>'admin.cursos.adicionar','uses'=>'Admin\CursoController@adicionar']);
Route::post('/admin/cursos/salvar',
['as'=>'admin.cursos.salvar','uses'=>'Admin\CursoController@salvar']);
Route::get('/admin/cursos/editar/{id}',
['as'=>'admin.cursos.editar','uses'=>'Admin\CursoController@editar']);
Route::put('/admin/cursos/atualizar/{id}',
['as'=>'admin.cursos.atualizar','uses'=>'Admin\CursoController@atualizar']);
Route::get('/admin/cursos/excluir/{id}',
['as'=>'admin.cursos.excluir','uses'=>'Admin\CursoController@excluir']);
}
